# HOW TO COMPILE AND RUN

To compile, make sure your current directiry contains the source code file, and run `g++ -std=c++11 lab2.cc -o NAME`

To run normally, execute `./NAME FILENAME`

To run with verbose output, execute `./NAME --verbose FILENAME`

NOTE: THIS LAB DOES NOT HANDLE FILENOTFOUND EXCEPTIONS