# HOW TO COMPILE AND RUN

To compile, make sure your current directiry contains the source code file, and run `g++ -std=c++11 lab1.cc -o NAME`

To run, run `./NAME`